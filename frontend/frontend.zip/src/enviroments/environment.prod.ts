export const environment = {
    production: true,
    apiUrl: '/api' // Usar proxy en producción
};